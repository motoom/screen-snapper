#ifndef JpegVclGlueH
#define JpegVclGlueH

void SaveToJpgFile(Graphics::TBitmap *Bm,const AnsiString &Filename,int Quality=90);
void LoadFromJpgFile(Graphics::TBitmap *Bm,const AnsiString &Filename);
void JpegSize(const AnsiString &Filename,int &W,int &H);
void LoadPartFromJpgFile(Graphics::TBitmap *Bm,int X,int Y,int W,int H,TColor Background,const AnsiString &Filename);

#endif
