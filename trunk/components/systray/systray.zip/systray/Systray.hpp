// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Systray.pas' rev: 5.00

#ifndef SystrayHPP
#define SystrayHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <ShellAPI.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Systray
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TSystray;
class PASCALIMPLEMENTATION TSystray : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	HWND FHandle;
	bool FInSysTray;
	bool FEnabled;
	Graphics::TIcon* FIcon;
	AnsiString FHint;
	Menus::TPopupMenu* FPopupMenu;
	_NOTIFYICONDATAA FNotifyIconData;
	Classes::TNotifyEvent FOnDblClick;
	Classes::TNotifyEvent FOnLeftClick;
	Classes::TNotifyEvent FOnRightClick;
	void __fastcall WndProc(Messages::TMessage &Message);
	void __fastcall CreateIcon(void);
	void __fastcall UpdateIcon(void);
	void __fastcall DestroyIcon(void);
	HICON __fastcall GetIconHandle(void);
	void __fastcall SetEnabled(bool Value);
	void __fastcall SetIcon(Graphics::TIcon* Value);
	void __fastcall SetHint(AnsiString Value);
	void __fastcall SetPopupMenu(Menus::TPopupMenu* Value);
	virtual void __fastcall Minimize(System::TObject* Sender);
	virtual void __fastcall Restore(System::TObject* Sender);
	void __fastcall DefaultOnDblClickEvent(System::TObject* Sender);
	void __fastcall DefaultOnRightClickEvent(System::TObject* Sender);
	
protected:
	virtual void __fastcall DblClick(void);
	virtual void __fastcall LeftClick(void);
	virtual void __fastcall RightClick(void);
	
public:
	__fastcall virtual TSystray(Classes::TComponent* AOwner);
	__fastcall virtual ~TSystray(void);
	__property HWND Handle = {read=FHandle, nodefault};
	__property bool InSystray = {read=FInSysTray, nodefault};
	
__published:
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=1};
	__property Graphics::TIcon* Icon = {read=FIcon, write=SetIcon};
	__property AnsiString Hint = {read=FHint, write=SetHint};
	__property Menus::TPopupMenu* PopupMenu = {read=FPopupMenu, write=SetPopupMenu, default=0};
	__property Classes::TNotifyEvent OnDblClick = {read=FOnDblClick, write=FOnDblClick};
	__property Classes::TNotifyEvent OnLeftClick = {read=FOnLeftClick, write=FOnLeftClick};
	__property Classes::TNotifyEvent OnRightClick = {read=FOnRightClick, write=FOnRightClick};
};


//-- var, const, procedure ---------------------------------------------------
static const Word WM_SYSTRAY = 0x800;
extern PACKAGE void __fastcall Register(void);

}	/* namespace Systray */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Systray;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Systray
