
// JpegVclGlue.cpp
//
// Interface to IJG's JPEG library to make it easier to work with VCL Bitmap objects.
//
// Sofware by Michiel Overtoom, motoom@xs4all.nl, 2004-2010
//

/* Compile notes for new versions of the lib:

- Check that project files are same as mentioned in makefile (avoid undefined symbol 'insufficient_data')

- Make sure borland struct packing is in jpeglib.h

	#ifdef __BORLANDC__
	#pragma option push -b
	#pragma option push -a4
	#endif

  (and appropriate pragma pops at the end)

- define HAVE_BOOLEAN before including jpeglib.h

- in jmorecfg.h redifine boolean:

	// typedef int boolean; // original
	typedef unsigned char boolean; // rpcnd.h defines it at such (motoom@xs4all.nl)

  OR: add to jconfig.h file:

	// Define "boolean" as unsigned char, not int, per Windows custom
	#ifndef __RPCNDR_H__	// don't conflict if rpcndr.h already read
	typedef unsigned char boolean;
	#endif
	#define HAVE_BOOLEAN	// prevent jmorecfg.h from redefining it


- order of RGB pixel ordering

	in jmorecfg.h:

    #ifdef __BORLANDC__	 // MO mod; Windows-style pixel ordering
    #define RGB_RED		2   // Offset of Red in an RGB scanline element
    #define RGB_GREEN	1	// Offset of Green
    #define RGB_BLUE	0	// Offset of Blue
    #else
    #define RGB_RED		0	// Offset of Red in an RGB scanline element
    #define RGB_GREEN	1	// Offset of Green
    #define RGB_BLUE	2	// Offset of Blue
    #endif
    #define RGB_PIXELSIZE	3	// JSAMPLEs per RGB scanline element

Still to check:

    Another report from a user of Borland C 4.5 was that incorrect code (leading
    to a color shift in processed images) was produced if any of the following
    optimization switch combinations were used:
        -Ot -Og
        -Ot -Op
        -Ot -Om
    So try backing off on optimization if you see such a problem.  (Are there
    several different releases all numbered "4.5"??)

*/

#include <vcl.h>
#pragma hdrstop
#include <stdio.h>
#include "jpeglib.h"
#include "JpegVclGlue.h"
#pragma package(smart_init)


static void SaveToJpgFileErrorhandler(j_common_ptr cinfo)
{
	char buffer[JMSG_LENGTH_MAX];
	(*cinfo->err->format_message)(cinfo, buffer);
	AnsiString Msg(buffer);
	throw Exception("SaveToJpgFile: Error: "+Msg);
}


static void LoadFromJpgFileErrorhandler(j_common_ptr cinfo)
{
	char buffer[JMSG_LENGTH_MAX];
	(*cinfo->err->format_message)(cinfo, buffer);
	AnsiString Msg(buffer);
	throw Exception("LoadFromJpgFile: Error: "+Msg);
}


void SaveToJpgFile(Graphics::TBitmap *Bm,const AnsiString &Filename,int Quality)
{
	struct jpeg_compress_struct cinfo;     // compression object
	struct jpeg_error_mgr jerr;
	FILE *outfile;

	outfile=fopen(Filename.c_str(),"wb");
	if (!outfile)
		throw Exception("SaveToJpgFile: Can't create output file '"+Filename+"'");

	cinfo.err=jpeg_std_error(&jerr);
	jerr.error_exit=SaveToJpgFileErrorhandler;
	try {
		Bm->PixelFormat=pf24bit;
		jpeg_create_compress(&cinfo);
		jpeg_stdio_dest(&cinfo,outfile);
		cinfo.image_width=Bm->Width;
		cinfo.image_height=Bm->Height;
		cinfo.input_components=3; // # of color components per pixel
		cinfo.in_color_space=JCS_RGB; // colorspace of input image
		jpeg_set_defaults(&cinfo);
		jpeg_set_quality(&cinfo,Quality,true);
		jpeg_start_compress(&cinfo,true);
		while (cinfo.next_scanline<cinfo.image_height) {
			unsigned char *DataPtr=(unsigned char *)Bm->ScanLine[cinfo.next_scanline];
			jpeg_write_scanlines(&cinfo,&DataPtr,1);
			}
		jpeg_finish_compress(&cinfo);
		}
	__finally {
		fclose(outfile);
		jpeg_destroy_compress(&cinfo);
		}
}


void LoadFromJpgFile(Graphics::TBitmap *Bm,const AnsiString &Filename)
{
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	FILE *infile=fopen(Filename.c_str(),"rb");
	if (!infile)
		throw Exception("LoadFromJpgFile: Cant open file '"+Filename+"'");

	try {
		cinfo.err=jpeg_std_error(&jerr);
		jerr.error_exit=LoadFromJpgFileErrorhandler;
		jpeg_create_decompress(&cinfo);
		jpeg_stdio_src(&cinfo,infile);
		jpeg_read_header(&cinfo,true);
		Bm->PixelFormat=pf24bit;
		Bm->Width=cinfo.image_width;
		Bm->Height=cinfo.image_height;
		jpeg_start_decompress(&cinfo);
		while (cinfo.output_scanline<cinfo.output_height) {
			unsigned char *Data=(unsigned char *)Bm->ScanLine[cinfo.output_scanline];
			jpeg_read_scanlines(&cinfo,&Data,1);
			}
		jpeg_finish_decompress(&cinfo);
		}
	__finally {
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		}
}


void JpegSize(const AnsiString &Filename,int &W,int &H)
{
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	FILE *infile=fopen(Filename.c_str(),"rb");
	if (!infile)
		throw Exception("JpegSize: Cant open file '"+Filename+"'");

	try {
		cinfo.err=jpeg_std_error(&jerr);
		jerr.error_exit=LoadFromJpgFileErrorhandler;
		jpeg_create_decompress(&cinfo);
		jpeg_stdio_src(&cinfo,infile);
		jpeg_read_header(&cinfo,true);
		W=cinfo.image_width;
		H=cinfo.image_height;
		}
	__finally {
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		}
}


void LoadPartFromJpgFile(Graphics::TBitmap *Bm,int X,int Y,int W,int H,TColor Background,const AnsiString &Filename)
{
	if (Filename=="") return;
	 
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	unsigned char *Buf=0;

	if (X<0)
		throw Exception("LoadPartFromJpgFile: X coordinate is < 0, not allowed");

	if (Y<0)
		throw Exception("LoadPartFromJpgFile: Y coordinate is < 0, not allowed");

	FILE *infile=fopen(Filename.c_str(),"rb");
	if (!infile)
		throw Exception("LoadPartFromJpgFile: Cant open file '"+Filename+"'");

	try {
		cinfo.err=jpeg_std_error(&jerr);
		jerr.error_exit=LoadFromJpgFileErrorhandler;
		jpeg_create_decompress(&cinfo);
		jpeg_stdio_src(&cinfo,infile);
		//
		jpeg_read_header(&cinfo,true);
		int JpgW=cinfo.image_width;
		int JpgH=cinfo.image_height;
		Buf=new unsigned char[JpgW*3];
		//
		Bm->Assign(0);
		Bm->PixelFormat=pf24bit;
		Bm->Canvas->Brush->Color=Background;
		Bm->Width=W;
		Bm->Height=H;
		//
		jpeg_start_decompress(&cinfo);
		int Line=0;
		int ScanlineByteOffset=X*3;
		int ScanlineBytesToCopy=W*3;
		//
		if (X+W>JpgW) {
			ScanlineBytesToCopy=(JpgW-X)*3;
			if (ScanlineBytesToCopy<0) ScanlineBytesToCopy=0;
			}
		//
		while (cinfo.output_scanline<cinfo.output_height) {
			jpeg_read_scanlines(&cinfo,&Buf,1);
			if (Line>=Y+H)
				break;
			else if (Line>=Y) {
				unsigned char *Dst=(unsigned char *)Bm->ScanLine[Line-Y];
				CopyMemory(Dst,Buf+ScanlineByteOffset,ScanlineBytesToCopy);
				}
			Line++;
			}
		// jpeg_finish_decompress removed due to 'app did not consume all scanlines' exception
		}
	__finally {
		if (Buf) delete[] Buf;
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		}
}

